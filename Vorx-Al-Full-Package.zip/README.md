# Vorx-Al Full Project

Instructions and details here.