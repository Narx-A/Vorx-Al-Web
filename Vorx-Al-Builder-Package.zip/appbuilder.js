function saveApp() {
  alert('💾 Ilova saqlandi!');
}
function previewApp() {
  alert('👀 Ilovani ko‘rish!');
}
function clearCanvas() {
  const dropArea = document.getElementById('drop-area');
  dropArea.innerHTML = '<p>🏗️ Elementlarni shu yerga sudrab tushiring</p>';
}